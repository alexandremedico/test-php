<?php
echo "Vous avez achetez cette objet";
 ?>
