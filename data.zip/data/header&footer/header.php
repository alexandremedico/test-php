<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="./style/style.css">
    <title>Test php</title>
    <div class="title">
      <h1>Ceci est un site de e-commerce en php</h1>
    </div>
  </head>
