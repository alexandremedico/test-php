<footer>
  <div class="footer">
    <p>Mentions légales</p>
    <p>Nous contacter</p>
    <p>Où nous trouver ?</p>
  </div>
</footer>
</html>
