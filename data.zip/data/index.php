<?php
require_once("./header&footer/header.php");
echo '<body>';
echo "<form class='' action='page.php' method='post'>";

  echo "<div class='img-all'>";
    echo "<div class='img1'>";
      echo "<img src='./img/sac.jpg' alt=''>";
      echo "<p> Price : 99euro </p>";
      echo "<input type='submit' name='achat1' value='Achetez!'>";
    echo "</div>";

    echo "<div class='img2'>";
      echo "<img src='./img/shoes.jpg' alt=''>";
      echo "<p> Price : 299euro </p>";
      echo "<input type='submit' name='achat2' value='Achetez!'>";
    echo "</div>";

    echo "<div class='img3'>";
      echo "<img src='./img/shoes1.jpg' alt=''>";
      echo "<p> Price : 1099euro </p>";
      echo "<input type='submit' name='achat3' value='Achetez!'>";
    echo "</div>";
  echo "</div>";

echo "</form>";
echo '</body>';
require_once("./header&footer/footer.php");
?>
